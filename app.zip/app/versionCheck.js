// Node.jsバージョンをコンソールに出力
console.log("Running Node version:", process.version);
